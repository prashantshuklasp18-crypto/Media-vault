# Encrypted Vault

An Android app for storing photos and videos with end-to-end AES-256-GCM encryption. Media is encrypted on-device before upload and can only be decrypted with the user's password.

## Features

- **Email/Password Authentication** — via Firebase Auth (with a mock/dev fallback when Firebase is not configured)
- **AES-256-GCM Encryption** — media is encrypted locally using PBKDF2-derived keys (210,000 iterations) before any cloud sync
- **Encrypted Cloud Sync** — encrypted blobs are uploaded to Firebase Storage
- **Local-First** — encrypted files are always stored locally; cloud sync is optional
- **Photo & Video Gallery** — grid view with thumbnails, video playback via ExoPlayer
- **Secure Session** — password is held in memory only; cleared on logout
- **Dark Theme UI** — built with Jetpack Compose and Material 3

## Project Structure

```
app/src/main/java/com/example/
├── VaultApp.kt                      # Application class, provides repository
├── MainActivity.kt                  # Entry point + Compose navigation
├── crypto/
│   └── VaultCrypto.kt               # AES-256-GCM encrypt/decrypt + PBKDF2 key derivation
├── data/
│   ├── VaultRepository.kt           # Auth, upload, download, delete logic
│   └── SessionManager.kt            # DataStore-based session persistence
├── database/
│   ├── VaultDatabase.kt             # Room database
│   ├── VaultDao.kt                  # DAO queries
│   └── VaultEntity.kt               # Room entity
├── model/
│   ├── UserSession.kt               # Session data class
│   └── VaultItem.kt                 # Vault item data class
└── ui/
    ├── theme/                       # Color, Typography, Theme
    ├── navigation/VaultNavigation.kt
    ├── viewmodel/
    │   ├── AuthViewModel.kt
    │   └── VaultViewModel.kt
    └── screens/
        ├── LoginScreen.kt
        ├── SignupScreen.kt
        ├── VaultScreen.kt           # Gallery grid
        └── MediaViewerScreen.kt     # Photo/image + video player
```

## Prerequisites

- **Android Studio** (Hedgehog 2023.1.1 or newer)
- **JDK 17** (bundled with Android Studio)
- **Android SDK** with compileSdk 34
- **Gradle 8.5** (the wrapper handles this)

## How to Build the APK

### Option A: Using Android Studio (Recommended)

1. **Download the project files** — copy all files from this project to your local machine.
2. Open Android Studio → **File → Open** → select the project root folder.
3. Wait for Gradle sync to complete (this may take a few minutes on first run).
4. To build a debug APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

### Option B: Using the Command Line

```bash
# 1. Generate the Gradle wrapper (first time only)
#    You need Gradle installed locally, OR use the one bundled with Android Studio:
#    /path/to/android-studio/gradle/gradle-X.X/bin/gradle wrapper

# 2. Build the debug APK
./gradlew assembleDebug

# 3. The APK is at:
#    app/build/outputs/apk/debug/app-debug.apk
```

### Installing the APK on a Device

```bash
# Enable USB debugging on your phone, connect it, then:
adb install app/build/outputs/apk/debug/app-debug.apk
```

Or simply copy the `.apk` file to your phone and tap it to install.

## Firebase Configuration (Optional)

The app works in a "dev mode" without Firebase — accounts are created locally and media stays on-device. To enable cloud sync:

1. Go to [Firebase Console](https://console.firebase.google.com/) and create a new project.
2. Add an Android app with package name `com.example.encryptedvault`.
3. Download `google-services.json` and place it in the `app/` directory.
4. Add the Google Services plugin to `app/build.gradle.kts`:
   ```kotlin
   plugins {
       id("com.google.gms.google-services")
   }
   ```
5. Enable **Email/Password** authentication in Firebase Console.
6. Enable **Cloud Storage** in Firebase Console.

Once configured, the app will use Firebase Auth for real accounts and Firebase Storage for encrypted cloud backups.

## Security Notes

- Encryption keys are derived from the user's password using PBKDF2 with HMAC-SHA256 (210,000 iterations, 256-bit key).
- Media is encrypted with AES-256-GCM (authenticated encryption).
- The password is never stored in plaintext — only kept in memory during the active session.
- Encrypted files use a custom binary format with a magic header (`EV1`), salt, IV, encrypted metadata, and encrypted payload.
- On logout, all decrypted cache files are deleted from the device.

## Tech Stack

| Layer | Technology |
|-------|-----------|
| UI | Jetpack Compose + Material 3 |
| Navigation | Navigation Compose |
| Database | Room (SQLite) |
| Auth | Firebase Auth (with mock fallback) |
| Storage | Firebase Storage (optional) |
| Crypto | AES-256-GCM + PBKDF2 |
| Image Loading | Coil |
| Video Playback | Media3 / ExoPlayer |
| Session | DataStore Preferences |
| Coroutines | Kotlin Coroutines + Flow |

## License

This is a sample project for educational purposes.
