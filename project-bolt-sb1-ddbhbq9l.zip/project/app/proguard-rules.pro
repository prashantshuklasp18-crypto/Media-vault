# Add project specific ProGuard rules here.
-keep class com.google.firebase.** { *; }
-keep class com.example.model.** { *; }
