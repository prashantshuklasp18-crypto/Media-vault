package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.UserSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "session")

class SessionManager(private val context: Context) {

    private object Keys {
        val UID = stringPreferencesKey("uid")
        val EMAIL = stringPreferencesKey("email")
        val PASS = stringPreferencesKey("pass")
    }

    val sessionFlow: Flow<UserSession?> = context.dataStore.data.map { prefs ->
        val uid = prefs[Keys.UID]
        val email = prefs[Keys.EMAIL]
        val pass = prefs[Keys.PASS]
        if (uid != null && email != null && pass != null) {
            UserSession(uid, email, pass.toCharArray())
        } else null
    }

    suspend fun saveSession(session: UserSession) {
        context.dataStore.edit { prefs ->
            prefs[Keys.UID] = session.uid
            prefs[Keys.EMAIL] = session.email
            prefs[Keys.PASS] = String(session.encryptionKeyChars)
        }
    }

    suspend fun clearSession() {
        context.dataStore.edit { it.clear() }
    }
}
