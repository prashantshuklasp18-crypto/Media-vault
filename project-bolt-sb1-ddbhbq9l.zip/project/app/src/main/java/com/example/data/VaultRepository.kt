package com.example.data

import android.content.Context
import android.net.Uri
import com.example.crypto.VaultCrypto
import com.example.database.VaultDao
import com.example.database.VaultEntity
import com.example.model.UserSession
import com.example.model.VaultItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class VaultRepository(
    private val context: Context,
    private val vaultDao: VaultDao
) {
    private val auth by lazy { runCatching { FirebaseAuth.getInstance() }.getOrNull() }
    private val storage by lazy { runCatching { FirebaseStorage.getInstance() }.getOrNull() }

    fun getItemsForUser(userId: String): Flow<List<VaultItem>> {
        return vaultDao.getItemsForUser(userId).map { entities ->
            entities.map { it.toVaultItem() }
        }
    }

    suspend fun signUp(email: String, pass: String): Result<UserSession> = withContext(Dispatchers.IO) {
        try {
            val authInstance = auth
            if (authInstance != null) {
                val res = authInstance.createUserWithEmailAndPassword(email, pass).await()
                val u = res.user ?: throw IllegalStateException("Signup failed")
                Result.success(UserSession(u.uid, u.email ?: email, pass.toCharArray()))
            } else {
                val mockUid = "dev_uid_" + UUID.nameUUIDFromBytes(email.toByteArray()).toString().substring(0, 8)
                Result.success(UserSession(mockUid, email, pass.toCharArray()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun login(email: String, pass: String): Result<UserSession> = withContext(Dispatchers.IO) {
        try {
            val authInstance = auth
            if (authInstance != null) {
                val res = authInstance.signInWithEmailAndPassword(email, pass).await()
                val u = res.user ?: throw IllegalStateException("Login failed")
                Result.success(UserSession(u.uid, u.email ?: email, pass.toCharArray()))
            } else {
                val mockUid = "dev_uid_" + UUID.nameUUIDFromBytes(email.toByteArray()).toString().substring(0, 8)
                Result.success(UserSession(mockUid, email, pass.toCharArray()))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun logout(session: UserSession?) {
        try { auth?.signOut() } catch (_: Exception) {}
        session?.clear()
        File(context.cacheDir, "decrypted_media").deleteRecursively()
    }

    suspend fun encryptAndUploadMedia(
        session: UserSession,
        mediaUri: Uri,
        onProgress: (Float) -> Unit = {}
    ): Result<VaultItem> = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val mimeType = contentResolver.getType(mediaUri) ?: "application/octet-stream"
            val isVideo = mimeType.startsWith("video")
            val rawBytes = contentResolver.openInputStream(mediaUri)?.use { it.readBytes() }
                ?: throw IllegalArgumentException("Could not read uri")

            val originalFileName = "vault_${System.currentTimeMillis()}.${if (isVideo) "mp4" else "jpg"}"
            val itemId = UUID.randomUUID().toString()
            val remotePath = "users/${session.uid}/media/$itemId.enc"

            val metadata = VaultCrypto.VaultMetadata(
                originalName = originalFileName,
                mimeType = mimeType,
                isVideo = isVideo,
                timestamp = System.currentTimeMillis(),
                originalSize = rawBytes.size.toLong()
            )

            val encryptedBlob = VaultCrypto.encryptMedia(rawBytes, metadata, session.encryptionKeyChars)

            val encFile = File(File(context.filesDir, "vault_encrypted").apply { mkdirs() }, "$itemId.enc")
            encFile.writeBytes(encryptedBlob)

            val decFile = File(File(context.cacheDir, "decrypted_media").apply { mkdirs() }, "$itemId.${if (isVideo) "mp4" else "jpg"}")
            decFile.writeBytes(rawBytes)

            var isSynced = false
            storage?.let { st ->
                val ref = st.reference.child(remotePath)
                ref.putBytes(
                    encryptedBlob,
                    StorageMetadata.Builder().setContentType("application/octet-stream").build()
                ).addOnProgressListener {
                    onProgress(it.bytesTransferred.toFloat() / it.totalByteCount.toFloat())
                }.await()
                isSynced = true
            }

            val entity = VaultEntity(
                id = itemId,
                userId = session.uid,
                remoteStoragePath = remotePath,
                originalFileName = originalFileName,
                mimeType = mimeType,
                isVideo = isVideo,
                fileSizeBytes = rawBytes.size.toLong(),
                timestamp = metadata.timestamp,
                localEncryptedPath = encFile.absolutePath,
                localDecryptedCachePath = decFile.absolutePath,
                isSynced = isSynced
            )
            vaultDao.insertOrUpdate(entity)

            Result.success(entity.toVaultItem())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteItem(session: UserSession, item: VaultItem): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            storage?.let { st ->
                runCatching { st.reference.child(item.remoteStoragePath).delete().await() }
            }
            item.localEncryptedPath?.let { File(it).delete() }
            item.localDecryptedCachePath?.let { File(it).delete() }
            vaultDao.deleteItem(item.id, session.uid)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun downloadAndDecrypt(
        session: UserSession,
        item: VaultItem
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val cacheFile = File(
                File(context.cacheDir, "decrypted_media").apply { mkdirs() },
                "${item.id}.${if (item.isVideo) "mp4" else "jpg"}"
            )

            if (cacheFile.exists() && cacheFile.length() > 0) {
                return@withContext Result.success(cacheFile)
            }

            val encryptedBlob: ByteArray = if (item.localEncryptedPath != null) {
                File(item.localEncryptedPath).readBytes()
            } else {
                val st = storage ?: throw IllegalStateException("Storage unavailable and no local copy")
                val maxBytes: Long = 50L * 1024 * 1024
                st.reference.child(item.remoteStoragePath).getBytes(maxBytes).await()
            }

            val (_, rawBytes) = VaultCrypto.decryptMedia(encryptedBlob, session.encryptionKeyChars)
            cacheFile.writeBytes(rawBytes)

            vaultDao.insertOrUpdate(
                VaultEntity(
                    id = item.id,
                    userId = session.uid,
                    remoteStoragePath = item.remoteStoragePath,
                    originalFileName = item.originalFileName,
                    mimeType = item.mimeType,
                    isVideo = item.isVideo,
                    fileSizeBytes = item.fileSizeBytes,
                    timestamp = item.timestamp,
                    localEncryptedPath = item.localEncryptedPath,
                    localDecryptedCachePath = cacheFile.absolutePath,
                    isSynced = true
                )
            )

            Result.success(cacheFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun VaultEntity.toVaultItem() = VaultItem(
        id = id,
        userId = userId,
        remoteStoragePath = remoteStoragePath,
        originalFileName = originalFileName,
        mimeType = mimeType,
        isVideo = isVideo,
        fileSizeBytes = fileSizeBytes,
        timestamp = timestamp,
        localEncryptedPath = localEncryptedPath,
        localDecryptedCachePath = localDecryptedCachePath,
        isSynced = isSynced
    )
}
