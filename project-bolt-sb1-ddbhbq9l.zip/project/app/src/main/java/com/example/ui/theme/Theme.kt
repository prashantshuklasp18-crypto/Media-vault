package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val VaultColorScheme = darkColorScheme(
    primary = VaultPrimary,
    onPrimary = VaultOnDark,
    primaryContainer = VaultPrimaryDark,
    onPrimaryContainer = VaultOnDark,
    secondary = VaultAccent,
    onSecondary = VaultOnDark,
    secondaryContainer = VaultAccentDark,
    onSecondaryContainer = VaultOnDark,
    tertiary = VaultWarning,
    onTertiary = VaultOnDark,
    error = VaultError,
    onError = VaultOnDark,
    errorContainer = VaultError,
    onErrorContainer = VaultOnDark,
    background = VaultDark,
    onBackground = VaultOnDark,
    surface = VaultDarkElevated,
    onSurface = VaultOnDark,
    surfaceVariant = VaultSurfaceVariant,
    onSurfaceVariant = VaultOnDarkMuted,
    outline = VaultOutline
)

@Composable
fun VaultTheme(content: @androidx.compose.runtime.Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VaultColorScheme,
        typography = VaultTypography,
        content = content
    )
}
