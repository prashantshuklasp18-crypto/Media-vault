package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.VaultRepository
import com.example.model.UserSession
import com.example.model.VaultItem
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class VaultUiState(
    val isLoading: Boolean = false,
    val uploadProgress: Float = 0f,
    val isUploading: Boolean = false,
    val error: String? = null,
    val message: String? = null
)

class VaultViewModel(
    private val repository: VaultRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(VaultUiState())
    val uiState: StateFlow<VaultUiState> = _uiState.asStateFlow()

    private var currentSession: UserSession? = null
    private var _items: StateFlow<List<VaultItem>> = MutableStateFlow(emptyList())
    val items: StateFlow<List<VaultItem>> get() = _items

    fun setSession(session: UserSession) {
        currentSession = session
        _items = repository.getItemsForUser(session.uid)
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    }

    fun uploadMedia(uri: Uri) {
        val session = currentSession ?: return
        _uiState.value = _uiState.value.copy(isUploading = true, uploadProgress = 0f, error = null)
        viewModelScope.launch {
            val result = repository.encryptAndUploadMedia(session, uri) { progress ->
                _uiState.value = _uiState.value.copy(uploadProgress = progress)
            }
            if (result.isSuccess) {
                _uiState.value = VaultUiState(message = "Upload complete")
            } else {
                _uiState.value = _uiState.value.copy(
                    isUploading = false,
                    error = result.exceptionOrNull()?.message ?: "Upload failed"
                )
            }
        }
    }

    fun deleteItem(item: VaultItem) {
        val session = currentSession ?: return
        viewModelScope.launch {
            val result = repository.deleteItem(session, item)
            if (result.isSuccess) {
                _uiState.value = _uiState.value.copy(message = "Item deleted")
            } else {
                _uiState.value = _uiState.value.copy(error = "Delete failed")
            }
        }
    }

    fun clearMessage() {
        _uiState.value = _uiState.value.copy(message = null, error = null)
    }

    companion object {
        fun factory(repository: VaultRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory() {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return VaultViewModel(repository) as T
                }
            }
    }
}
