package com.example.model

data class VaultItem(
    val id: String,
    val userId: String,
    val remoteStoragePath: String,
    val originalFileName: String,
    val mimeType: String,
    val isVideo: Boolean,
    val fileSizeBytes: Long,
    val timestamp: Long,
    val localEncryptedPath: String?,
    val localDecryptedCachePath: String?,
    val isSynced: Boolean
)
