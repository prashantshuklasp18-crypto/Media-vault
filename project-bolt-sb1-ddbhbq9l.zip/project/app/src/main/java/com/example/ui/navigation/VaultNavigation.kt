package com.example.ui.navigation

sealed class VaultRoute(val route: String) {
    object Login : VaultRoute("login")
    object Signup : VaultRoute("signup")
    object Vault : VaultRoute("vault")
    object Viewer : VaultRoute("viewer/{itemId}")
    fun viewer(itemId: String) = "viewer/$itemId"
}
