package com.example.model

data class UserSession(
    val uid: String,
    val email: String,
    private val encryptionKeyChars: CharArray
) {
    val encryptionKeyChars: CharArray get() = field

    fun clear() {
        encryptionKeyChars.fill(0.toChar())
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is UserSession) return false
        return uid == other.uid && email == other.email
    }

    override fun hashCode(): Int = uid.hashCode() * 31 + email.hashCode()
}
