package com.example.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultDao {

    @Query("SELECT * FROM vault_items WHERE userId = :userId ORDER BY timestamp DESC")
    fun getItemsForUser(userId: String): Flow<List<VaultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(entity: VaultEntity)

    @Query("SELECT * FROM vault_items WHERE id = :id")
    suspend fun getById(id: String): VaultEntity?

    @Query("DELETE FROM vault_items WHERE id = :id AND userId = :userId")
    suspend fun deleteItem(id: String, userId: String)

    @Query("DELETE FROM vault_items WHERE userId = :userId")
    suspend fun deleteAllForUser(userId: String)
}
