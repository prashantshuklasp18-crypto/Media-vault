package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.SessionManager
import com.example.model.VaultItem
import com.example.ui.navigation.VaultRoute
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MediaViewerScreen
import com.example.ui.screens.SignupScreen
import com.example.ui.screens.VaultScreen
import com.example.ui.theme.VaultTheme
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.VaultViewModel
import java.io.File

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VaultTheme {
                VaultNavGraph()
            }
        }
    }

    @Composable
    private fun VaultNavGraph() {
        val app = application as VaultApp
        val repository = app.vaultRepository
        val sessionManager = remember { SessionManager(this) }
        val navController = rememberNavController()

        val authViewModel: AuthViewModel = viewModel(
            factory = AuthViewModel.factory(repository, sessionManager)
        )
        val vaultViewModel: VaultViewModel = viewModel(
            factory = VaultViewModel.factory(repository)
        )

        val authState by authViewModel.uiState.collectAsState()
        val vaultState by vaultViewModel.uiState.collectAsState()
        val items by vaultViewModel.items.collectAsState()

        var decryptedFile by remember { mutableStateOf<File?>(null) }
        var viewerLoading by remember { mutableStateOf(false) }
        var viewerError by remember { mutableStateOf<String?>(null) }
        var viewingItem by remember { mutableStateOf<VaultItem?>(null) }

        LaunchedEffect(authState.session) {
            val session = authState.session
            if (session != null) {
                vaultViewModel.setSession(session)
                val route = navController.currentDestination?.route
                if (route == VaultRoute.Login.route || route == VaultRoute.Signup.route) {
                    navController.navigate(VaultRoute.Vault.route) {
                        popUpTo(VaultRoute.Login.route) { inclusive = true }
                    }
                }
            }
        }

        NavHost(
            navController = navController,
            startDestination = VaultRoute.Login.route
        ) {
            composable(VaultRoute.Login.route) {
                LoginScreen(
                    onLoginSuccess = { },
                    onNavigateToSignup = { navController.navigate(VaultRoute.Signup.route) },
                    onLogin = { email, pass -> authViewModel.login(email, pass) },
                    isLoading = authState.isLoading,
                    error = authState.error
                )
            }

            composable(VaultRoute.Signup.route) {
                SignupScreen(
                    onSignupSuccess = { },
                    onNavigateToLogin = { navController.popBackStack() },
                    onSignup = { email, pass -> authViewModel.signUp(email, pass) },
                    isLoading = authState.isLoading,
                    error = authState.error
                )
            }

            composable(VaultRoute.Vault.route) {
                VaultScreen(
                    items = items,
                    isUploading = vaultState.isUploading,
                    uploadProgress = vaultState.uploadProgress,
                    error = vaultState.error,
                    message = vaultState.message,
                    onAddMedia = { uri -> vaultViewModel.uploadMedia(uri) },
                    onMediaClick = { item ->
                        viewingItem = item
                        viewerLoading = true
                        viewerError = null
                        decryptedFile = null
                        navController.navigate(VaultRoute.viewer(item.id))
                    },
                    onDeleteItem = { item -> vaultViewModel.deleteItem(item) },
                    onLogout = {
                        authViewModel.logout()
                        navController.navigate(VaultRoute.Login.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    },
                    onClearMessage = { vaultViewModel.clearMessage() }
                )
            }

            composable(VaultRoute.Viewer.route) { backStackEntry ->
                val itemId = backStackEntry.arguments?.getString("itemId") ?: ""
                val item = items.find { it.id == itemId } ?: viewingItem

                LaunchedEffect(itemId) {
                    val session = authState.session
                    if (session != null && item != null) {
                        viewerLoading = true
                        viewerError = null
                        val result = repository.downloadAndDecrypt(session, item)
                        if (result.isSuccess) {
                            decryptedFile = result.getOrNull()
                            viewerLoading = false
                        } else {
                            viewerError = result.exceptionOrNull()?.message ?: "Failed to decrypt"
                            viewerLoading = false
                        }
                    }
                }

                if (item != null) {
                    MediaViewerScreen(
                        item = item,
                        decryptedFile = decryptedFile,
                        isLoading = viewerLoading,
                        error = viewerError,
                        onBack = {
                            decryptedFile = null
                            viewingItem = null
                            navController.popBackStack()
                        }
                    )
                }
            }
        }
    }
}
