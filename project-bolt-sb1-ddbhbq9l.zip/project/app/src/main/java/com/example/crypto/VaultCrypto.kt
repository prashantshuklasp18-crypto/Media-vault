package com.example.crypto

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object VaultCrypto {

    private const val GCM_IV_LENGTH = 12
    private const val GCM_TAG_BITS = 128
    private const val PBKDF2_ITERATIONS = 210_000
    private const val KEY_BITS = 256
    private const val SALT_LENGTH = 16

    data class VaultMetadata(
        val originalName: String,
        val mimeType: String,
        val isVideo: Boolean,
        val timestamp: Long,
        val originalSize: Long
    )

    private fun deriveKey(passwordChars: CharArray, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(passwordChars, salt, PBKDF2_ITERATIONS, KEY_BITS)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val derived = factory.generateSecret(spec)
        return SecretKeySpec(derived.encoded, "AES")
    }

    private fun gcmCipher(key: SecretKey, iv: ByteArray, encryptMode: Boolean): Cipher {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val spec = GCMParameterSpec(GCM_TAG_BITS, iv)
        if (encryptMode) cipher.init(Cipher.ENCRYPT_MODE, key, spec)
        else cipher.init(Cipher.DECRYPT_MODE, key, spec)
        return cipher
    }

    fun encryptMedia(
        rawBytes: ByteArray,
        metadata: VaultMetadata,
        passwordChars: CharArray
    ): ByteArray {
        val salt = ByteArray(SALT_LENGTH).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(GCM_IV_LENGTH).also { SecureRandom().nextBytes(it) }
        val key = deriveKey(passwordChars, salt)

        val metaJson = serializeMetadata(metadata)
        val metaBytes = metaJson.toByteArray(Charsets.UTF_8)

        val cipher = gcmCipher(key, iv, encryptMode = true)
        val encryptedMedia = cipher.doFinal(rawBytes)

        val cipher2 = gcmCipher(key, iv, encryptMode = true)
        val encryptedMeta = cipher2.doFinal(metaBytes)

        val baos = ByteArrayOutputStream()
        DataOutputStream(baos).use { dos ->
            dos.writeUTF("EV1")
            dos.writeInt(salt.size); dos.write(salt)
            dos.writeInt(iv.size); dos.write(iv)
            dos.writeInt(encryptedMeta.size); dos.write(encryptedMeta)
            dos.writeInt(encryptedMedia.size); dos.write(encryptedMedia)
        }
        return baos.toByteArray()
    }

    fun decryptMedia(
        encryptedBlob: ByteArray,
        passwordChars: CharArray
    ): Pair<VaultMetadata, ByteArray> {
        val dis = DataInputStream(ByteArrayInputStream(encryptedBlob))
        val magic = dis.readUTF()
        require(magic == "EV1") { "Invalid vault file format" }

        val salt = ByteArray(dis.readInt()).also { dis.readFully(it) }
        val iv = ByteArray(dis.readInt()).also { dis.readFully(it) }
        val encryptedMeta = ByteArray(dis.readInt()).also { dis.readFully(it) }
        val encryptedMedia = ByteArray(dis.readInt()).also { dis.readFully(it) }

        val key = deriveKey(passwordChars, salt)

        val metaCipher = gcmCipher(key, iv, encryptMode = false)
        val metaBytes = metaCipher.doFinal(encryptedMeta)
        val metadata = deserializeMetadata(String(metaBytes, Charsets.UTF_8))

        val mediaCipher = gcmCipher(key, iv, encryptMode = false)
        val rawBytes = mediaCipher.doFinal(encryptedMedia)

        return metadata to rawBytes
    }

    private fun serializeMetadata(m: VaultMetadata): String {
        return buildString {
            append('{')
            append("\"originalName\":\"").append(escape(m.originalName)).append('"')
            append(",\"mimeType\":\"").append(escape(m.mimeType)).append('"')
            append(",\"isVideo\":").append(m.isVideo)
            append(",\"timestamp\":").append(m.timestamp)
            append(",\"originalSize\":").append(m.originalSize)
            append('}')
        }
    }

    private fun deserializeMetadata(s: String): VaultMetadata {
        val map = mutableMapOf<String, String>()
        val content = s.trim().removeSurrounding("{", "}")
        val parts = content.split(",")
        for (part in parts) {
            val idx = part.indexOf(':')
            if (idx > 0) {
                val k = part.substring(0, idx).trim().trim('"')
                val v = part.substring(idx + 1).trim().trim('"')
                map[k] = v
            }
        }
        return VaultMetadata(
            originalName = map["originalName"] ?: "unknown",
            mimeType = map["mimeType"] ?: "application/octet-stream",
            isVideo = map["isVideo"]?.toBoolean() ?: false,
            timestamp = map["timestamp"]?.toLongOrNull() ?: 0L,
            originalSize = map["originalSize"]?.toLongOrNull() ?: 0L
        )
    }

    private fun escape(s: String): String = s.replace("\\", "\\\\").replace("\"", "\\\"")
}
