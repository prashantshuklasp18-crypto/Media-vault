package com.example

import android.app.Application
import com.example.data.VaultRepository
import com.example.database.VaultDatabase

class VaultApp : Application() {

    val vaultRepository: VaultRepository by lazy {
        VaultRepository(this, VaultDatabase.getInstance(this).vaultDao())
    }

    companion object {
        lateinit var instance: VaultApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }
}
