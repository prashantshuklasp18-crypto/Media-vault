package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VaultDark = Color(0xFF0D1117)
val VaultDarkElevated = Color(0xFF161B22)
val VaultSurface = Color(0xFF1C2333)
val VaultSurfaceVariant = Color(0xFF232D3F)
val VaultPrimary = Color(0xFF2563EB)
val VaultPrimaryDark = Color(0xFF1D4ED8)
val VaultAccent = Color(0xFF10B981)
val VaultAccentDark = Color(0xFF059669)
val VaultError = Color(0xFFEF4444)
val VaultWarning = Color(0xFFF59E0B)
val VaultSuccess = Color(0xFF10B981)
val VaultOnDark = Color(0xFFE6EDF3)
val VaultOnDarkMuted = Color(0xFF8B949E)
val VaultOutline = Color(0xFF30363D)
