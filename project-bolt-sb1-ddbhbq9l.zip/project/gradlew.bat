@rem
@rem Minimal Gradle wrapper for Windows
@rem Run `gradle wrapper` on your machine to generate the full gradlew.bat and gradle-wrapper.jar.
@rem
@if "%OS%"=="Windows_NT" setlocal
set DIRNAME=%~dp0
java -classpath "%DIRNAME%\gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
